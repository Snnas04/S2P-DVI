document.getElementById('goBackButton').addEventListener('click', () => {
    window.appMessages.goBack();
  });