const { app, BrowserWindow, ipcMain, Notification} = require('electron');
const path =  require('path');

let mainWindow;
let modalWindow;

// Crear la ventana principal
const createWindow = () => {
    mainWindow = new BrowserWindow({
        show: false,
        minWidth: 1520,
        minHeight: 930,
        webPreferences: {
            preload: path.join(__dirname, './js/preload.js')
        },
    });
    mainWindow.webContents.openDevTools(); // sirve para poder visualizar las herramientas de desarrollador
    // cargar el index.html en la app.
    mainWindow.loadFile('index.html')
    mainWindow.once("ready-to-show", () => {
        mainWindow.show();
    });
    mainWindow.maximize();
    mainWindow.focus();

    function showNotificationAndWait(title, body) {
        return new Promise((resolve) => {
            const notification = new Notification({title: title, body: body});
            notification.on('click', () => {
                resolve();
            });
            notification.on('close', () => {
                resolve();
            });

            notification.show();
        })
    }

    ipcMain.on('gesture', async (event, gestureType) => {
        const title = 'Notificación desde el proceso Main.';
        let body;

        switch (gestureType) {
            case 'changeBackground':
                body = 'Gesto detectado. Se va a cambiar el color de fondo.';
                break;
            case 'closeApp':
                body = 'Gesto detectado. Se va a cerrar la aplicacion.';
                break;
            default:
                body = 'Notificación por defecto.';
                break;
        }

        await showNotificationAndWait(title, body);

        if (gestureType === 'changeBackground') {

            mainWindow.setBackgroundColor('#808080');

            await new Promise(resolve => setTimeout(() => {
                mainWindow.setBackgroundColor('#FFFFFF');
                mainWindow.webContents.send('rock-status', false);
            }, 4000));
        }

        if (gestureType === 'closeApp') {

        }
    });

    return mainWindow;
};

// Crear la ventana secundaria
const createSecondaryWindow = () => {
    secondaryWindow = new BrowserWindow({
        show: false,
        width: 1420,
        height: 930,
        webPreferences: {
            // No es una buena práctica hacerlo, de hecho la propia herramienta te avisa de peligro de seguridad
            contextIsolation: false,
            nodeIntegration: true
        }
    });
    //secondaryWindow.webContents.openDevTools();
    secondaryWindow.loadFile("./html/modal.html");
    // solo mostrará la ventana cuando la tenga totalmente lista para mostrar
    secondaryWindow.once("ready-to-show", () => {
        secondaryWindow.show();
    });
    secondaryWindow.focus();

    // comunicacion IPC para cerrar la ventana modal al realizar el submit del formulario o con el boton de cerrar
    ipcMain.on('close-secondary-window', () => {
        if (secondaryWindow) {
            console.log("Closing all windows.")
            secondaryWindow.close();
        }
    });
};

// This method will be called when Electron has finished
// initialization and is ready to create browser windows.
// Some APIs can only be used after this event occurs.
app.whenReady().then(() => {
    createWindow();
});

app.on('activate', () => {
    // On macOS it's common to re-create a window in the app when the
    // dock icon is clicked and there are no other windows open.
    if (BrowserWindow.getAllWindows().length === 0) createWindow();
});

// Quit when all windows are closed, except on macOS. There, it's common
// for applications and their menu bar to stay active until the user quits
// explicitly with Cmd + Q.
app.on('window-all-closed', () => {
    if (process.platform !== 'darwin') app.quit()
});
