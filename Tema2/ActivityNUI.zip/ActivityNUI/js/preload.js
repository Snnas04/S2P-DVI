const {contextBridge, ipcRenderer} = require('electron');

contextBridge.exposeInMainWorld('appComunication', {
   sendGestureMessage: (gestureType) => {
       ipcRenderer.send('gesture', gestureType);
   },
    onUpdateRockGesture:(callback) => {
       ipcRenderer.on('rock-status', callback)
    },
});