//const fp = require('fingerpose');

const config = {
    video: { width: 800, height: 600, fps: 80 }
};

const landmarkColors = {
    thumb: 'red',
    index: 'blue',
    middle: 'yellow',
    ring: 'green',
    pinky: 'pink',
    wrist: 'white'
};

const gestureStrings = {
    'llamame': '🤙',
    'stop': '🤚​',
    'rock': '🤟​',
};

async function createDetector() {
    return window.handPoseDetection.createDetector(
        window.handPoseDetection.SupportedModels.MediaPipeHands,
        {
            runtime: "mediapipe",
            modelType: "full",
            maxHands: 2,
            solutionPath: `https://cdn.jsdelivr.net/npm/@mediapipe/hands@0.4.1646424915`,
        }
    );
}

let rockGestureDetected = false;
async function main() {
    const video = document.querySelector("#webcam");
    const canvas = document.querySelector("#canvas");
    const ctx = canvas.getContext("2d");

    const resultLayer = {
        right: document.querySelector("#pose-result-right"),
        left: document.querySelector("#pose-result-left")
    }

    // añadir gesto personalizado
    const callMeGesture = new fp.GestureDescription('llamame');
    const stopGesture = new fp.GestureDescription('stop');
    const rockGesture = new fp.GestureDescription('rock');

    /* PERSONALIZACION GESTO LLAMAME */
    // Thumb and Pinky fingers
    callMeGesture.addCurl(fp.Finger.Thumb, fp.FingerCurl.NoCurl);
    callMeGesture.addCurl(fp.Finger.Pinky, fp.FingerCurl.HalfCurl);

    callMeGesture.addDirection(fp.Finger.Thumb, fp.FingerDirection.VerticalUp, 0.9);
    callMeGesture.addDirection(fp.Finger.Thumb, fp.FingerDirection.DiagonalUpLeft, 0.9);
    callMeGesture.addDirection(fp.Finger.Thumb, fp.FingerDirection.DiagonalUpRight, 0.9);
    callMeGesture.addDirection(fp.Finger.Pinky, fp.FingerDirection.HorizontalLeft, 0.9);
    callMeGesture.addDirection(fp.Finger.Pinky, fp.FingerDirection.HorizontalRight, 0.9);
    callMeGesture.addDirection(fp.Finger.Pinky, fp.FingerDirection.DiagonalDownRight, 0.9);
    callMeGesture.addDirection(fp.Finger.Pinky, fp.FingerDirection.DiagonalDownLeft, 0.9);

    // other fingers
    for(let finger of [fp.Finger.Index, fp.Finger.Middle, fp.Finger.Ring]) {
        callMeGesture.addCurl(finger, fp.FingerCurl.FullCurl, 1.0);
        callMeGesture.addCurl(finger, fp.FingerCurl.HalfCurl, 0.9);
        callMeGesture.addDirection(finger, fp.FingerDirection.HorizontalLeft, 0.9);
        callMeGesture.addDirection(finger, fp.FingerDirection.HorizontalRight, 0.9);
        callMeGesture.addDirection(finger, fp.FingerDirection.DiagonalDownRight, 0.8);
        callMeGesture.addDirection(finger, fp.FingerDirection.DiagonalDownLeft, 0.8);
    }

    /* PERSONALIZACION GESTO STOP */
    //Thumb finger
    stopGesture.addCurl(fp.Finger.Thumb, fp.FingerCurl.NoCurl);
    stopGesture.addDirection(fp.Finger.Thumb, fp.FingerDirection.VerticalUp, 0.9);
    stopGesture.addDirection(fp.Finger.Thumb, fp.FingerDirection.DiagonalUpLeft, 0.8);
    stopGesture.addDirection(fp.Finger.Thumb, fp.FingerDirection.DiagonalUpRight, 0.8);

    //other fingers
    for(let finger of [fp.Finger.Index, fp.Finger.Middle, fp.Finger.Ring, fp.Finger.Pinky]) {
        stopGesture.addCurl(finger, fp.FingerCurl.NoCurl);
        stopGesture.addDirection(finger, fp.FingerDirection.VerticalUp, 0.9);
    }

    /* PERSONALIZACION GESTO ROCK */
    // Thumb finger
    rockGesture.addCurl(fp.Finger.Thumb, fp.FingerCurl.NoCurl);
    rockGesture.addCurl(fp.Finger.Thumb, fp.FingerCurl.HalfCurl);
    rockGesture.addDirection(fp.Finger.Thumb, fp.FingerDirection.HorizontalLeft, 0.9);
    rockGesture.addDirection(fp.Finger.Thumb, fp.FingerDirection.HorizontalRight, 0.9);
    rockGesture.addDirection(fp.Finger.Thumb, fp.FingerDirection.DiagonalUpLeft, 0.8);
    rockGesture.addDirection(fp.Finger.Thumb, fp.FingerDirection.DiagonalUpRight, 0.8);

    // Index and Pinky fingers
    for(let finger of [fp.Finger.Index, fp.Finger.Pinky]) {
        rockGesture.addCurl(finger, fp.FingerCurl.NoCurl);
        rockGesture.addCurl(finger, fp.FingerCurl.HalfCurl);

        rockGesture.addDirection(finger, fp.FingerDirection.VerticalUp, 0.9);
        rockGesture.addDirection(finger, fp.FingerDirection.DiagonalUpLeft, 0.7);
        rockGesture.addDirection(finger, fp.FingerDirection.DiagonalUpRight, 0.7);
    }

    // Middle and Ring fingers
    for(let finger of [fp.Finger.Middle, fp.Finger.Ring]) {
        rockGesture.addCurl(finger, fp.FingerCurl.FullCurl);
        //rockGesture.addCurl(finger, fp.FingerCurl.HalfCurl);

        rockGesture.addDirection(finger, fp.FingerDirection.VerticalUp, 0.9);
    }

    // configure gesture estimator
    const knownGestures = [
        callMeGesture,
        stopGesture,
        rockGesture
    ]
    const GE = new fp.GestureEstimator(knownGestures)
    // load handpose model
    const detector = await createDetector()
    console.log("mediaPose model loaded")

    // main estimation loop
    const estimateHands = async () => {

        // clear canvas overlay
        ctx.clearRect(0, 0, config.video.width, config.video.height)
        resultLayer.right.innerText = ''
        resultLayer.left.innerText = ''

        // get hand landmarks from video
        const hands = await detector.estimateHands(video, {
            flipHorizontal: true
        })

        const handsMap = new Map();

        for (const hand of hands) {
            for (const keypoint of hand.keypoints) {
                const name = keypoint.name.split('_')[0].toString().toLowerCase()
                const color = landmarkColors[name]
                drawPoint(ctx, keypoint.x, keypoint.y, 3, color)
            }

            const est = GE.estimate(hand.keypoints3D, 9)
            if (est.gestures.length > 0) {

                // find gesture with highest match score
                let result = est.gestures.reduce((p, c) => {
                    return (p.score > c.score) ? p : c
                })
                const chosenHand = hand.handedness.toLowerCase()
                resultLayer[chosenHand].innerText = gestureStrings[result.name]
                //updateDebugInfo(est.poseData, chosenHand);

                handsMap.set(chosenHand, result.name);
            }

            if(handsMap.has("left") || handsMap.has("right")) {
                if(handsMap.get("left") === "rock" || handsMap.get("right") === "rock") {
                    if (!rockGestureDetected) {
                        rockGestureDetected = true;
                        window.appComunication.sendGestureMessage("changeBackground");
                    }
                }
            }

        }
        // ...and so on
        setTimeout(() => { estimateHands() }, 1000 / config.video.fps)
    }

    estimateHands()
    console.log("Starting predictions");
}

async function initCamera(width, height, fps) {

    const constraints = {
        audio: false,
        video: {
            facingMode: "user",
            width: width,
            height: height,
            frameRate: { max: fps }
        }
    }

    const video = document.querySelector("#webcam")
    video.width = width
    video.height = height

    // get video stream
    const stream = await navigator.mediaDevices.getUserMedia(constraints)
    video.srcObject = stream

    return new Promise(resolve => {
        video.onloadedmetadata = () => { resolve(video) }
    })
}

function drawPoint(ctx, x, y, r, color) {
    ctx.beginPath()
    ctx.arc(x, y, r, 0, 2 * Math.PI)
    ctx.fillStyle = color
    ctx.fill()
}

window.addEventListener("DOMContentLoaded", () => {

    initCamera(
        config.video.width, config.video.height, config.video.fps
    ).then(video => {
        video.play()
        video.addEventListener("loadeddata", event => {
            console.log("Camera is ready")
            //main()
        })
    })

    const canvas = document.querySelector("#canvas")
    canvas.width = config.video.width
    canvas.height = config.video.height
    console.log("Canvas initialized")
});

const buttonFingerPose = document.getElementById("buttonActivateFinger")
buttonFingerPose.addEventListener('click' , async () => {
    try {
        await main();
    } catch (error) {
        console.error('Error al ejecutar main:', error);
    }
})

window.appComunication.onUpdateRockGesture((_event, value) => {
    rockGestureDetected = value;
});